import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import {OrderBy} from './orderBy';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { EmpServiceService } from './emp-service.service';
import { AddempComponent } from './addemp/addemp.component';
import { ShowempComponent } from './showemp/showemp.component';
import { SearchstudentComponent } from './searchstudent/searchstudent.component';


@NgModule({
  declarations: [
    AppComponent,
    AddempComponent,
    ShowempComponent,
    OrderBy,
    SearchstudentComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient, EmpServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
