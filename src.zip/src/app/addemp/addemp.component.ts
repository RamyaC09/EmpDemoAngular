import { Component, OnInit } from '@angular/core';
import {EmpServiceService, Employee} from '../emp-service.service';

@Component({
  selector: 'app-addemp',
  templateUrl: './addemp.component.html',
  styleUrls: ['./addemp.component.css']
})
export class AddempComponent implements OnInit
 {
    service: EmpServiceService;
    emp: Employee;

  constructor(service: EmpServiceService) 
  {
    this.service  = service;
  }

  ngOnInit() {
  }

  add(data: any)
  {
    this.emp = new Employee(data.id, data.name);
    this.service.addData(this.emp);
  }

}
