import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService 
{
  http: HttpClient;
  fetch: boolean = false;
  emp1: Employee[] = [];
  constructor(http: HttpClient) {
    this.http = http;
   }


fetchData()
{
  this.http.get('./assets/emp.json').subscribe(
    data => {
      if (!this.fetch)
      {
        this.convert(data);
        this.fetch = true;
      }
   }
  )
}

convert(data: any)
{
  for(let e of data)
  {
    let em = new Employee(e.id, e.name);
    this.emp1.push(em);
  }
}

getData(): Employee[]
{
  return this.emp1;
}

addData(e: any)
{
  this.emp1.push(e);
}

updateEmp(d: any)
{
  let eid = d.id;
  for(let i=0;i<this.emp1.length;i++)
  {
    if(eid == this.emp1[i].id)
    {
      this.emp1[i].id = d.id;
      this.emp1[i].name = d.name;
    }
  }
}
}

export class Employee
{
 static COLUMNS=['id','name'];  id: number;
  name: string;
  constructor(id: number, name: string)
  {
    this.id = id;
    this.name = name;
  }
}